package com.info.catbreeds.adapter

import android.view.View

interface CatClickListener {

    fun onCatClicked(v : View)
}